class Factorial {
public static boolean b;
	public static int factorial(int a,int b, int c, int d) {
	};;;;;;;;;;

	public static void main(String[] args) {
		int argument,teste;
		int n;
	};;;;
	public static double ole(int n) {
		
	}
}
